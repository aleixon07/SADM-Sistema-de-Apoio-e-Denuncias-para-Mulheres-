<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chuquel Ferragens - ADM</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Coming+Soon&family=Lora&display=swap" rel="stylesheet">

    <meta name="author" content="Ane">


    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body{
            background-color: black;
            
        }

        p{
            font-size: 50px;
        }

        h1{
            color: yellow;
            font-size: 70px;
            margin-bottom: 60px;
        }
       
        p a{
            color: rgb(255, 255, 255);
            text-decoration: none;
        }

        p a:hover{
            color: yellow;
        }

       
       

    </style>
</head>

<body>
    <h1 align="center">ADMINISTRAÇÃO</h1>

               <div class="container">
               <p align="center"><a href="./index.php">HOME</a></p>
               <p align="center"><a href="./listar_adm.php">ADMINISTRADORES</a></p>
               <p align="center"><a href="./produtos.php">PRODUTOS</a></p>
               </div>
            
            <!--menu-->
        



</body>

</html>

<!--localhost/ferragem/interface_adm.php
-->